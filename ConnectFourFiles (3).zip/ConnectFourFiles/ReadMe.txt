﻿ReadMe .txt for CS


Program Description and Construction:
This program allows a user to play a game of Connect4 against a computer.  The human player always goes first.  The computer uses the strategy set by the difficulty as described below.
Classes:
Board - this class monitors the board, which is a list of lists, as it progresses through the game.  Initializing this class creates a list of lists.  There are a number of functions in this class that monitor the status of the board - where things are in rows, columns, and diagonals and how far down a column a placed tile will fall.


Computer Strategy - this class allows the computer to make decisions about which column to place a tile in based on the game pieces already on the board.
The function playStrategy tells the computer which function to use to set a column, based on the difficulty of the game. The easy strategy is just to choose a random column.
The function ‘medium’ has the computer choose which column to play based on which row or column has the best chance of the computer winning in that turn.  Thus, it scans a dictionary of all the rows,columns, and diagonals to find which place has the most pieces of its own color and plays in a space that will add to the number of pieces of its own color in that row or column.
The function ‘hard’ has the computer choose which column to play based on which row or column its opponent is most likely to win on.  Thus, it scans a dictionary of all the rows,columns, and diagonals to find which place has the most pieces of its opponent’s color and plays in a space that will block its opponent from continuing to play in that direction.
The function ‘advanced’ has the computer choose which column to play based on which row or column has the most tiles of a single color in it.  Thus, it scans a dictionary of all the rows, columns, and diagonals to find which place has the most pieces of a given color in a row.  Then it plays the piece in the correct column to block a row or column of its opponent’s color or to add to a long row or column of its own color.
The function getColumnFromDictionary takes in the dictionary that was used to select a column in which to play, finds the spot that the computer chose to play, and then figures out which column in the board corresponds to that space.  For a desired dictionary key that represents a column (all of which are named col#, where # is an integer 0 - 6 and corresponds to the actual column) , the computer simply checks the number in the fourth position in the key and assigns that as the column.  For a desired dictionary key that represents a row (all of which are named row#, where # is an integer 0-5 and 5 corresponds to the bottom row of the board while 0 is the top), the computer 
        
Functions outside of classes:
                These functions organize the gameplay and the graphic interface.
playConnectFour - plays the whole game of connect4 and allows the user to choose to play again if desired.
opening - interface that allows the user to select a location and difficulty
gamePlay - the function that draws and monitors the status of the game board
getBackground - allows the user to select a background
getDifficulty - allows user to select difficulty
getHumanColumn - allows user to select column
tileFall - animates the tile falling
drawWin - draws the screen to celebrate a user win
drawLoss - draws the screen for a computer win
drawTie - draws the screen for a tie between user and computer (very difficult to achieve but includes puns, so we encourage you to try to tie the game)
playAgain - allows the user to choose to play the game again


Current Status of Program:
The program has four levels of computer strategies which each play a different strategy. To play the user clicks a column and their piece is played. Immediately after, the computer strategy will play a piece. This continues until someone has four pieces in a row. The program has a detailed graphical component that allows the player to view the game and watch tiles fall into place. Additionally, the user can choose ‘where’ to play the game around campus which will set a background image for the game. The interface shows a win, loss, or tie screen at the end of game play. Users can then choose to play again, which opens a new window with the new game or not which closes the current window. 
The four levels of computer strategy are easy, medium, hard, and advanced. None of the computer strategies can identify diagonal groups, and will not attempt to block or create from a diagonal. The game can recognize a diagonal and the game will end with a win if there are four pieces of the same color in a diagonal. The easy computer strategy will play a piece completely at random, and is easy to beat. The medium computer strategy will attempt to build its own four in a row or column regardless of where the human user is playing. Because the human goes first, the human WILL win in 4 moves if they play 4 in a row immediately, unless the computer randomly blocks the progress. The hard strategy will only look to block the user, and will not intentionally create its own connect four this creates a game that is more difficult to win, but the computer is still unlikely to win. The advanced strategy will both block the user and attempt to create its own connect four.  It is the most difficult strategy to beat.  Medium, Hard, and Advanced strategies all check to make sure that if it wants to add to a row, there are enough pieces below the actually desired space so that the correct tiles align.  Otherwise they play randomly.
         There are still some weaknesses in the strategy functions that allow a user to win fairly easily regardless of the chosen difficulty. One such weakness is that for advanced and hard,  if there is a row containing (“maize”,”maize”,blank,”maize”) the computer does not necessarily know to place a piece in that blank space to block a win.  Another is that in the medium strategy, the computer may try to build a row even if there is not enough space in the board to build a row.  Overall, the computer’s strategy is much stronger for columns than for rows, which is likely due to the way our dictionary was constructed. For instance, if the computer cannot complete a row due to a blank space beneath the desired spaces, it simply places a tile randomly rather than playing elsewhere.  Also, it can only perform that check for blank spaces on the left side of a row, not on the right.
 One thing worth noting is that by the improvements that we made in the row strategy, the computer may now play in upper spaces of columns in an attempt to complete rows.  This may look like the fixes we made where the computer wasted time filling columns where it couldn’t win were broken, however that still works it is just a new strategy element.


Instructions for running the program: 
The program runs from the command line as connectFour.py as long as the picture files and graphics.py are included in the same module.